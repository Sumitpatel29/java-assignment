import java.util.Scanner;

public class FibonacciUsingLoopandRecursion 
{
	static Scanner sc=new Scanner(System.in);

	public static void main(String[] args) 
	{
		System.out.println("Enter nth fibonacci series: ");
		int n=sc.nextInt();
        for (int i = 0; i < n; i++) {
            System.out.print(fib(i) + " ");
        }
	}
	static int fib(int n)
	{
		{
	        if (n == 0) 
	            return 0;
	        else if (n == 1) 
	            return 1;
	        
	        return fib(n - 1) + fib(n - 2);  
	    }
	}
}
