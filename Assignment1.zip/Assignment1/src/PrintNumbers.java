import java.util.*;

public class PrintNumbers 
{
	static Scanner sc= new Scanner (System.in);
	public static void main(String[] args) 
	{
		int x,y;
		System.out.println("Enter Starting number:" );
		x=sc.nextInt();
		System.out.println("Enter Starting number:" );
		y=sc.nextInt();
		display(x,y);

	}
	static void display(int x,int y)
	{
		while(x<=y)
		{
			System.out.print(x+" ");
			x++;
		}
	}

}
