import java.util.Scanner;

public class PrintNumbersRecursion 
{
	static Scanner sc= new Scanner(System.in);
	public static void main(String[] args) 
	{
		int x,y;
		System.out.println("Enter values of x and y");
		x=sc.nextInt();
		y=sc.nextInt();
		display(x,y);

	}
	static void display(int x,int y)
	{
		if (x>y)
		{
			return;
		}
		System.out.println(x+" ");
		display(x+1,y);
	}
}
