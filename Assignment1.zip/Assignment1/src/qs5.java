
public class qs5 {

	public static void main(String[] args) 
	{
		int hs1=67000;
		int fc1=2300;
		float tx1=0.025f;
		
		int hs2=62000;
		int fc2=2500;
		float tx2=0.025f;
		
		int hs3=75000;
		int fc3=1850;
		float tx3=0.020f;
		System.out.println("House Cost1= "+ totalcost(hs1, fc1, tx1));
		System.out.println("House Cost2= "+ totalcost(hs2, fc2, tx2));
		System.out.println("House Cost3= "+ totalcost(hs3, fc3, tx3));
		
		
		
	}
	static float totalcost(int hs,int fc,float tx)
	{
		float taxAnnum=hs*tx;
		return ((hs+fc)*5+taxAnnum*5);
	}

}
